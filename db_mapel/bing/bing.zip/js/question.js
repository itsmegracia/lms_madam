// Array dari object
const quiz = [
  // Nomer 1
  {
    q: "",
    options: [
      "1, 2, 3",
      "2, 3, 4",
      "3, 4, 2",
      "4, 1, 2"
    ],
    answer: 2,
  },

];

